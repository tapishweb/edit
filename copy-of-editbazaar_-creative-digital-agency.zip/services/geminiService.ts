
import { GoogleGenAI, Chat } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export function startChatSession(): Chat {
  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: 'You are a helpful and friendly chatbot for EditBazaar, a creative digital agency. Your goal is to answer user questions about the agency\'s services which include: Social Media Management, Content Creation & Editing, Digital Marketing, and Web Development. Be concise and professional.',
    },
  });
  return chat;
}

export async function sendMessageToBot(chat: Chat, message: string): Promise<string> {
  try {
    const result = await chat.sendMessage({ message: message });
    return result.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm sorry, but I encountered an error while processing your request.";
  }
}
