
import React from 'react';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-32">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            className="overflow-hidden rounded-2xl"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8 }}
          >
            <img
              src="https://picsum.photos/800/900?grayscale"
              alt="EditBazaar Creative Team"
              className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-orbitron font-bold">
              Creativity meets
              <span className="text-[#00C2FF] drop-shadow-[0_0_10px_#00C2FF]"> Strategy.</span>
            </h2>
            <p className="mt-6 text-lg text-white/70 leading-relaxed">
              At EditBazaar, our mission is to empower brands by transforming their digital presence. We believe in the power of organic growth, fueled by compelling visuals and authentic storytelling. Our team of creatives and strategists work hand-in-hand to craft unique narratives that not only capture attention but also build lasting connections with your audience.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
