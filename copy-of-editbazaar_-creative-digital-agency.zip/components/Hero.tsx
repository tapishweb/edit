import React from 'react';
import { motion } from 'framer-motion';

const FloatingShape: React.FC<{ className: string; delay: number }> = ({ className, delay }) => (
  <motion.div
    className={`absolute ${className} bg-white/5 rounded-lg border border-white/10`}
    initial={{ opacity: 0, scale: 0.5, rotate: Math.random() * 360 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 1, delay }}
    whileInView={{
      y: [0, -20, 0],
      rotate: [0, Math.random() * 90, 0],
      transition: {
        duration: 8 + Math.random() * 10,
        repeat: Infinity,
        repeatType: 'reverse',
        ease: 'easeInOut',
        delay: Math.random() * 2,
      },
    }}
  />
);

const Hero: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: [0.6, 0.01, 0.05, 0.95],
      },
    },
  };

  return (
    <section id="hero" className="relative h-screen flex items-center justify-center text-center overflow-hidden">
      <FloatingShape className="w-16 h-16 top-[15%] left-[10%]" delay={0.2} />
      <FloatingShape className="w-24 h-24 top-[20%] right-[15%]" delay={0.4} />
      <FloatingShape className="w-8 h-8 bottom-[25%] left-[20%]" delay={0.6} />
      <FloatingShape className="w-20 h-20 bottom-[15%] right-[10%]" delay={0.8} />

      <motion.div
        className="z-10 container mx-auto px-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.h1
          className="text-5xl md:text-8xl font-orbitron font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-400"
          style={{
            textShadow: '0 0 15px rgba(0, 194, 255, 0.5), 0 0 30px rgba(0, 194, 255, 0.3)',
          }}
          variants={itemVariants}
        >
          We Create, You Grow.
        </motion.h1>
        <motion.p className="mt-6 text-xl md:text-2xl max-w-3xl mx-auto text-white/80" variants={itemVariants}>
          A creative powerhouse for brands that want to stand out online.
        </motion.p>
        <motion.div className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-4" variants={itemVariants}>
          <a
            href="#portfolio"
            className="w-full sm:w-auto px-8 py-4 bg-[#00C2FF] text-black font-bold text-lg rounded-full hover:scale-105 transition-transform duration-300 shadow-[0_0_25px_#00C2FF]"
          >
            View Work
          </a>
          <a
            href="#contact"
            className="w-full sm:w-auto px-8 py-4 border-2 border-white/50 text-white font-bold text-lg rounded-full hover:bg-white/10 hover:border-white transition-all duration-300"
          >
            Get a Quote
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;