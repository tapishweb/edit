import React from 'react';
import { EditBazaarLogo } from './icons/EditBazaarLogo';
import { TwitterIcon, InstagramIcon, LinkedInIcon } from './icons/SocialIcons';


const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050505] py-12">
      <div className="container mx-auto px-6 text-center text-white/50">
        <div className="flex justify-center items-center mb-6">
            <EditBazaarLogo className="h-10 w-auto text-[#00C2FF]" />
            <span className="font-orbitron text-3xl font-bold tracking-widest ml-3">EDITBAZAAR</span>
        </div>
        <div className="flex justify-center space-x-6 mb-6">
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#00C2FF] transition-colors duration-300"><TwitterIcon /></a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#00C2FF] transition-colors duration-300"><InstagramIcon /></a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#00C2FF] transition-colors duration-300"><LinkedInIcon /></a>
        </div>
        <a href="mailto:contact@editbazaar.com" className="mb-2 inline-block hover:text-[#00C2FF] transition-colors duration-300">contact@editbazaar.com</a>
        <p>&copy; {new Date().getFullYear()} EditBazaar. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;