
import React from 'react';
import { motion } from 'framer-motion';

const testimonials = [
  { name: 'John Doe', company: 'Innovate Inc.', feedback: 'EditBazaar transformed our online presence. Their creativity is unmatched!', logo: 'https://picsum.photos/100/100?random=5' },
  { name: 'Jane Smith', company: 'Future Corp.', feedback: 'The results speak for themselves. Our engagement has skyrocketed since we started working with them.', logo: 'https://picsum.photos/100/100?random=6' },
  { name: 'Sam Wilson', company: 'Growth Co.', feedback: 'A truly professional and dedicated team. They understood our vision perfectly.', logo: 'https://picsum.photos/100/100?random=7' },
];

const TestimonialCard: React.FC<typeof testimonials[0]> = ({ name, company, feedback, logo }) => {
  return (
    <motion.div
      className="bg-[#1A1A1A] p-8 rounded-xl border border-white/10 relative overflow-hidden"
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.6 }}
    >
      <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-[radial-gradient(circle_farthest-side,rgba(0,194,255,0.15),rgba(0,194,255,0))] animate-spin-slow"></div>
      <p className="text-lg text-white/80 italic mb-6 relative z-10">"{feedback}"</p>
      <div className="flex items-center gap-4 relative z-10">
        <img src={logo} alt={company} className="w-14 h-14 rounded-full border-2 border-[#00C2FF]" />
        <div>
          <h4 className="font-bold text-lg">{name}</h4>
          <p className="text-[#00C2FF]">{company}</p>
        </div>
      </div>
    </motion.div>
  );
};


const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 md:py-32 bg-black/20">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-4xl md:text-5xl font-orbitron font-bold text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          What Our Clients Say
        </motion.h2>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
