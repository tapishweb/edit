
import React from 'react';

export const EditBazaarLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    {...props}
    viewBox="0 0 24 24"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M12 2L2 7V17L12 22L22 17V7L12 2ZM12 4.4L19.6 8.4V15.6L12 19.6L4.4 15.6V8.4L12 4.4Z"
    />
    <path
        d="M12 7L7 9.8V14.2L12 17L17 14.2V9.8L12 7ZM12 15.2L8.8 13.3V10.7L12 8.8L15.2 10.7V13.3L12 15.2Z"
    />
  </svg>
);
