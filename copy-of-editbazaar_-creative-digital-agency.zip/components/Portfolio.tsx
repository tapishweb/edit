import React from 'react';
import { motion } from 'framer-motion';

const portfolioItems = [
  { id: 1, title: 'Project Alpha', category: 'Web Development', img: 'https://picsum.photos/600/400?random=1' },
  { id: 2, title: 'Project Beta', category: 'Social Media', img: 'https://picsum.photos/600/400?random=2' },
  { id: 3, title: 'Project Gamma', category: 'Content Creation', img: 'https://picsum.photos/600/400?random=3' },
  { id: 4, title: 'Project Delta', category: 'Digital Marketing', img: 'https://picsum.photos/600/400?random=4' },
];

const PortfolioItem: React.FC<{ item: typeof portfolioItems[0] }> = ({ item }) => {
  return (
    <motion.div
      className="relative rounded-lg overflow-hidden group aspect-video"
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.05, zIndex: 10 }}
    >
      <img src={item.img} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
        <h3 className="text-xl font-bold font-orbitron text-white">{item.title}</h3>
        <p className="text-[#00C2FF]">{item.category}</p>
      </div>
    </motion.div>
  );
};

const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-20 md:py-32">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-4xl md:text-5xl font-orbitron font-bold text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Featured Work
        </motion.h2>
        <div className="grid sm:grid-cols-2 gap-8">
          {portfolioItems.map((item) => (
            <PortfolioItem key={item.id} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;