import React from 'react';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert("Thank you for your message! We'll get back to you soon.");
    e.currentTarget.reset();
  };

  const handleBookCall = () => {
    window.open('https://calendly.com/', '_blank');
  };

  return (
    <section id="contact" className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_120%,rgba(0,194,255,0.2),transparent)]"></div>
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-4xl md:text-6xl font-orbitron font-bold">
            Let's Build Your Brand Together.
          </h2>
          <form className="mt-12 space-y-6" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="relative group">
                <input required type="text" placeholder="Your Name" className="w-full bg-[#1A1A1A] border-2 border-white/20 rounded-lg py-4 px-5 text-lg text-white focus:outline-none focus:border-[#00C2FF] transition-colors duration-300" />
                <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00C2FF] to-[#FFCC00] rounded-lg blur opacity-0 group-focus-within:opacity-75 transition duration-300"></div>
              </div>
               <div className="relative group">
                <input required type="email" placeholder="Your Email" className="w-full bg-[#1A1A1A] border-2 border-white/20 rounded-lg py-4 px-5 text-lg text-white focus:outline-none focus:border-[#00C2FF] transition-colors duration-300" />
                <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00C2FF] to-[#FFCC00] rounded-lg blur opacity-0 group-focus-within:opacity-75 transition duration-300"></div>
              </div>
            </div>
            <div className="relative group">
                <textarea required placeholder="Your Message" rows={5} className="w-full bg-[#1A1A1A] border-2 border-white/20 rounded-lg py-4 px-5 text-lg text-white focus:outline-none focus:border-[#00C2FF] transition-colors duration-300 resize-none"></textarea>
                <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00C2FF] to-[#FFCC00] rounded-lg blur opacity-0 group-focus-within:opacity-75 transition duration-300"></div>
            </div>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4">
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-4 bg-[#00C2FF] text-black font-bold text-lg rounded-full hover:scale-105 transition-transform duration-300 shadow-[0_0_25px_#00C2FF]"
              >
                Let's Talk
              </button>
              <button
                type="button"
                onClick={handleBookCall}
                className="w-full sm:w-auto px-8 py-4 bg-transparent border-2 border-[#FFCC00] text-[#FFCC00] font-bold text-lg rounded-full hover:bg-[#FFCC00] hover:text-black transition-all duration-300 hover:shadow-[0_0_20px_#FFCC00]"
              >
                Book a Free Strategy Call
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;