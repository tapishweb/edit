
import React from 'react';
import { motion } from 'framer-motion';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, icon, description }) => {
  return (
    <motion.div
      className="p-8 bg-[#1A1A1A]/50 rounded-2xl border border-white/10 group cursor-pointer"
      style={{ transformStyle: 'preserve-3d' }}
      whileHover={{ scale: 1.05, transition: { duration: 0.3 } }}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.5 }}
    >
      <div
        className="relative transition-transform duration-500 group-hover:[transform:translateZ(20px)]"
      >
        <div className="mb-4 text-[#00C2FF] drop-shadow-[0_0_8px_#00C2FF]">
          {icon}
        </div>
        <h3 className="text-2xl font-bold font-orbitron mb-2">{title}</h3>
        <p className="text-white/70">{description}</p>
      </div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"></div>
    </motion.div>
  );
};

const Services: React.FC = () => {
    const servicesData = [
    {
      title: 'Social Media Management',
      description: 'Building communities and driving engagement with strategic content and consistent presence.',
      icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>,
    },
    {
      title: 'Content Creation & Editing',
      description: 'From viral videos to stunning visuals, we produce content that stops the scroll and tells your story.',
      icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>,
    },
    {
      title: 'Digital Marketing',
      description: 'Maximizing your reach and ROI with data-driven SEO, PPC, and email marketing campaigns.',
      icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>,
    },
    {
      title: 'Web Design & Development',
      description: 'Creating immersive, high-performance websites that offer a seamless user experience.',
      icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>,
    },
  ];


  return (
    <section id="services" className="py-20 md:py-32 bg-[#0A0A0A] relative">
       <div className="absolute inset-0 bg-[radial-gradient(circle_500px_at_50%_200px,#00c2ff20,transparent)]"></div>
      <div className="container mx-auto px-6 relative z-10">
        <motion.h2
          className="text-4xl md:text-5xl font-orbitron font-bold text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Our Services
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8" style={{ perspective: '1000px' }}>
          {servicesData.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
